# PotholesSegAnnotations > 2025-03-12 11:26am
https://universe.roboflow.com/potholeobjectdetection/potholessegannotations

Provided by a Roboflow user
License: CC BY 4.0

